SHEDS Stream Temperature Database
=================================

Jeffrey D Walker, PhD <jeff@walkerenvres.com>
Walker Environmental Research LLC

Data Exported On:   Nov 20, 2019 (for model v1.1.1)
Archive Created On: Jun 22, 2020

Description:
  This zip file contains daily stream temperature data exported from the SHEDS
  Stream Temperature Database. This dataset only includes public monitoring
  locations. The raw observation data have been aggregated to daily time steps.
  The data have undergone minimal processing and screening aside from the
  aggregation and filtering for only public locations.

Table Schema:
  agencies 1->n locations 1->n series 1->n values

Joining Relationships:
  locations.agency_id -> agencies.agency_id
  locations.featureid -> catchments shapefile (featureid)
  series.location_id -> locations.location_id
  values.series_id -> series.series_id

Notes:

The daily `values` are first grouped by `series`. Each `series` is considered
a single continuous time series of observed temperatures (i.e. a deployment).
The `series` are grouped by `location`, which is a fixed monitoring station.
The `locations` are grouped by `agency`, which is the organization or entity
that collected the data.

The `values` table contains the daily min, mean, max stream temperature (degC)
as well as the number of observations (n). If `n=1` for all values within a
single series then that series was likely uploaded as pre-aggregated daily
data (and thus the min, mean, max will all be the same). The values table
also includes a `flagged` column with associated `comment`. A daily value will
have `flagged=TRUE` if at least one of the observations during that day was
flagged (but not necessarily all of them).

The `reviewed` column of the `series` table indicates whether the
timeseries has undergone QAQC review by the user using the SHEDS QAQC tool
on the database website. Any series with `review=TRUE` has been reviewed
by the user by *not* by SHEDS team. If `review=FALSE` then the series
has not been reviewed yet and may contain out-of-water or other 
flag events.
